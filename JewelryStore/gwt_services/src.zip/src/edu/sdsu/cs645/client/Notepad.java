package edu.sdsu.cs645.client;

import edu.sdsu.cs645.shared.FieldVerifier;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.*;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.*;
import com.google.gwt.user.client.ui.RichTextArea.ExtendedFormatter;
import com.google.gwt.user.client.Window;
import java.util.*;

public class Notepad implements EntryPoint {

	private static final String SERVER_ERROR = "An error occurred while " + "attempting to contact the server. Please check your network " + "connection and try again.";


	private final NotepadServiceAsync notepadService = GWT.create(NotepadService.class);
	private RichTextArea pad;
	private HTML status;
	ExtendedFormatter formatter;
	private ListBox fontsize;
	private final String extention = ".txt";

	public void onModuleLoad() {
		status = new HTML();
		pad = new RichTextArea();
		// buildMainPanel();
		buildLogin();


	}

	private void buildLogin() {
		FlowPanel loginPanel = new FlowPanel();
		loginPanel.getElement().setId("log_panel");
		final PasswordTextBox password = new PasswordTextBox();
		password.setStyleName("pass");
		loginPanel.add(new HTML("<h1> Please Enter Your Password </h1>"));
		loginPanel.add(new Label("Password"));
		loginPanel.add(password);
		FlowPanel bPanel = new FlowPanel();
		bPanel.setStyleName("blog_panel");
		Button loginButton = new Button("Login");
		Button clearButton = new Button("Clear");
		loginButton.setStyleName("log_button");
		clearButton.setStyleName("log_button");
		clearButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent e) {
				password.setText("");
			}
		});
		loginButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent e) {
				validateLogin(password.getText());
			}
		});
		bPanel.add(clearButton);
		bPanel.add(loginButton);
		loginPanel.add(bPanel);
		loginPanel.add(status);
		RootPanel.get().add(loginPanel);
		password.setFocus(true);

	}
	private void buildMainPanel() {
		FlowPanel main = new FlowPanel();
		main.add(new HTML("<h1>Welcome to Online Notepad</h1>"));
		main.add(getButtonPanel());

		main.add(pad);
		main.add(status);

		RootPanel.get().clear();
		RootPanel.get().add(main);
		// Create new Instance of vertical panel to align the widgets
		VerticalPanel vp = new VerticalPanel();
		vp.setStyleName("upload_panel");
		// Add label
		vp.add(new HTML("<label>Choose file to Upload:</label>"));
		// Create new Instance of FileUpload 
		final FileUpload fileUpload = new FileUpload();
		// Create button for submit
		Button uploadButton = new Button("Upload");
		uploadButton.setStyleName("upload_button");
		// Add ClickHandler to the button
		uploadButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				//Get file name	
				String filename = fileUpload.getFilename();
				// Check the length of the filename
				if (filename.length() != 0) {
					Window.alert("File was successfully uploaded");
				} else Window.alert("No file choosen");
			}
		});

		// Add widgets to Vertical Panel
		vp.add(fileUpload);
		vp.add(uploadButton);


		//Add Vertical Panel to Root Panel
		RootPanel.get().add(vp);
		loadPanel();

	}
	private FlowPanel getButtonPanel() {


		FlowPanel p = new FlowPanel();
		VerticalPanel vp = new VerticalPanel();
		Button save = new Button("Save");
		Button load = new Button("Load");
		Button loadMap = new Button("Load Map");
		Button clr = new Button("Clear");
		clr.setStyleName("my_button");
		save.setStyleName("my_button");
		load.setStyleName("my_button");
		loadMap.setStyleName("my_button");

		pad = new RichTextArea();
		pad.setText("Enter Text Here ..");
		formatter = pad.getExtendedFormatter();
		fontsize = new ListBox();
		fontsize.addItem("XX-Small");
		fontsize.addItem("X-Small");
		fontsize.addItem("Small");
		fontsize.addItem("Medium");
		fontsize.addItem("Large");
		fontsize.addItem("X-Large");
		fontsize.addItem("XX-Large");
		// fontsize.setSize("100px", "20px");

		fontsize.addChangeHandler(new ChangeHandler() {
			public void onChange(ChangeEvent event) {
				if (fontsize.isItemSelected(0)) formatter.setFontSize(RichTextArea.FontSize.XX_SMALL);

				if (fontsize.isItemSelected(1)) formatter.setFontSize(RichTextArea.FontSize.X_SMALL);

				if (fontsize.isItemSelected(2)) formatter.setFontSize(RichTextArea.FontSize.SMALL);

				if (fontsize.isItemSelected(3)) formatter.setFontSize(RichTextArea.FontSize.MEDIUM);

				if (fontsize.isItemSelected(4)) formatter.setFontSize(RichTextArea.FontSize.LARGE);

				if (fontsize.isItemSelected(5)) formatter.setFontSize(RichTextArea.FontSize.X_LARGE);

				if (fontsize.isItemSelected(6)) formatter.setFontSize(RichTextArea.FontSize.XX_LARGE);

			}
		});


		save.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent e) {
				savePanel();
			}
		});


		load.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent e) {
				loadPanel();
			}
		});

		loadMap.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent e) {
				loadMap();
			}
		});


		clr.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent e) {
				pad.setText("");
			}
		});

		Button italics = new Button("Italics");
		italics.setStyleName("format");
		italics.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent e) {
				formatter.toggleItalic();
			}
		});

		Button ul = new Button("Underline");
		ul.setStyleName("format");
		ul.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent e) {
				formatter.toggleUnderline();
			}
		});
		Button bold = new Button("Bold");
		bold.setStyleName("format");
		bold.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent e) {
				formatter.toggleBold();
			}
		});



		p.setStyleName("button_panel");
		p.add(fontsize);
		p.add(italics);
		p.add(ul);
		p.add(bold);
		p.add(save);
		p.add(load);
		p.add(loadMap);
		p.add(clr);


		return p;


	}
	private void savePanel() {
		AsyncCallback callback = new AsyncCallback() {
			public void onSuccess(Object results) {
				status.setText((String) results);
			}
			public void onFailure(Throwable err) {}
		};
		notepadService.save(pad.getHTML(), callback);
	}

	private void loadPanel() {
		AsyncCallback callback = new AsyncCallback() {
			public void onSuccess(Object results) {
				pad.setHTML((String) results);
			}
			public void onFailure(Throwable err) {}
		};
		notepadService.load(callback);
	}

	private void loadMap() {
		AsyncCallback callback = new AsyncCallback() {
			public void onSuccess(Object results) {
				TreeMap t = (TreeMap) results;
				String toDisplay = "<table>";
				Iterator < String > k = t.keySet().iterator();
				Iterator < String > v = t.values().iterator();

				while (k.hasNext()) {
					toDisplay += "<tr>";
					toDisplay += "<td>" + k.next() + "</td>";
					toDisplay += "<td>" + v.next() + "</td>";
					toDisplay += "</tr>";

				}
				toDisplay += "</table>";
				pad.setHTML(toDisplay);
			}
			public void onFailure(Throwable err) {}
		};
		notepadService.loadMap(callback);
	}
	private void validateLogin(String password) {
		AsyncCallback callback = new AsyncCallback() {
			public void onSuccess(Object results) {
				String answer = ((String) results);
				if (answer.equals("OK")) {
					status.setText("");
					buildMainPanel();
				} else status.setText("Invalid password");
			}
			public void onFailure(Throwable err) {
				status.setText("Failed" + err.getMessage());
			}
		};
		notepadService.validateLogin(password, callback);
	}



}